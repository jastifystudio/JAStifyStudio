import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import './header.css';
import logo from '../../assets/images/logo.png';

function Header(props) {

    const navigate = useNavigate();

    return (
        <div data-component="header">
            <div className="main-cnt">
                <div className="header-section">
                    <img className="header-logo" src={logo}></img>
                    <span className="header-app-name"><span style={{color:'#ff3d3c'}}>JAS</span>tify Studio</span>
                </div>
                <div className="header-section" style={{ gap: '20px' }}>
                    <span className="header-section-option" onClick={() => navigate('/')}>Home</span>
                    <span className="header-section-option" onClick={() => navigate('/templates')}>Templates</span>
                    <span className="header-section-option" onClick={() => navigate('/about')}>About</span>
                    <span className="header-section-option" onClick={() => navigate('/contact')}>Contact</span>
                </div>
                <div className="header-section">
                </div>
            </div>
        </div>
    )
}

export default Header
