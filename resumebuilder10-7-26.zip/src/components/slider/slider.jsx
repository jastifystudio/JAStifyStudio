import { useState } from 'react'
import { useNavigate } from 'react-router-dom';
import './slider.css';
import sliderImage from '../../assets/images/homepage-hero.avif';
import sliderImage1 from '../../assets/images/cactus-animation.svg';

function Slider() {

    const navigate = useNavigate();

    const student = [
        {
            name: "Jagdeep", rollno: 12, subMarks: [
                { subject: "Maths", marks: 80, total: 100 },
                { subject: "hindi", marks: 80, total: 100 },
                { subject: "sst", marks: 80, total: 90 },
                { subject: "punjabi", marks: 80, total: 90 },
            ]
        },
        {
            name: "Rohit", rollno: 13, subMarks: [
                { subject: "Maths", marks: 80, total: 100 },
                { subject: "hindi", marks: 80, total: 100 },
                { subject: "sst", marks: 80, total: 90 },
                { subject: "punjabi", marks: 80, total: 90 },
            ]
        },
        {
            name: "mansih", rollno: 14, subMarks: [
                { subject: "Maths", marks: 80, total: 100 },
                { subject: "hindi", marks: 80, total: 100 },
                { subject: "sst", marks: 80, total: 90 },
                { subject: "punjabi", marks: 80, total: 90 },
            ]
        },
    ]


    const onCreateResume = () => {
        navigate('/resumeStudio')
    }


    return (
        <div data-component="slider">
            <div className="main-cnt">
                <div className="slider-left-cnt">
                    <img style={{ height: '90%', position: 'absolute', zIndex: 1 }} src={sliderImage}></img>
                    <img className="wave-cactus-sway" src={sliderImage1}></img>
                </div>
                <div className="slider-right-cnt">
                    <h1 className="slider-heading">
                        <span style={{ color: '#ff3d3c' }}>JAS</span>tify Studio
                        <br />
                        Smart Resume Builder
                    </h1>
                    <p className="slider-content">Create your perfect resume from any device with our free AI Resume Builder. Access content suggestions, ATS-friendly templates, & expert tips to get hired fast.</p>
                    <button className="slider-button" onClick={onCreateResume}>Build my resume today</button>
                </div>
            </div>
        </div>
    )
}

export default Slider
