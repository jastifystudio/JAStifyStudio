import { useEffect, useState } from 'react'
import { useNavigate } from 'react-router-dom';
import './footer.css';
import logo from '../../assets/images/logo.png';

function Footer(props) {

    const navigate = useNavigate();

    return (
        <div data-component="footer">
            <div className="main-cnt">
                <h1>FOOTER SECTION PAGE DESIGN</h1>
            </div>
        </div>
    )
}

export default Footer
