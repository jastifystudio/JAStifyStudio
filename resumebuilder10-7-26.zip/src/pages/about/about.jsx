import { useState } from 'react'
import './about.css'
import Header from '../../components/header/header'

function About() {

  return (
    <div data-component="about">
      <div className='main-cnt'>
        <Header />
        <h1 style={{color:'red'}}>ABOUT PAGE</h1>
      </div>
    </div>
  )
}

export default About
