import { useState } from 'react'
import './templates.css'
import Header from '../../components/header/header'
import logo from '../../assets/images/logo.png';
import TemplateTypeCard from '../../components/template-type-card/templateTypeCard';
import Slider from '../../components/slider/slider';
import Footer from '../../components/footer/footer';

function Templates() {

  const templateTypes = [
    { image: logo, name: "Template type name", content: "Choose a customizable template built to impress employers and pass ATS scans." },
    { image: logo, name: "Template type name", content: "Choose a customizable template built kjsdhjkfshf dkfbsdfbfds fjdfdf jf sdmffjhsdb ." },
    { image: logo, name: "Template type name", content: "shdgf sdjgfjhs jgsdjfgds jhdsfgjsd sdjfhkjsdfh jsddfhkjh." },
    { image: logo, name: "Template type name", content: "shdgf sdjgfjhs jgsdjfgds jhdsfgjsd sdjfhkjsdfh jsddfhkjh." },
    { image: logo, name: "Template type name", content: "shdgf sdjgfjhs jgsdjfgds jhdsfgjsd sdjfhkjsdfh jsddfhkjh." },
    { image: logo, name: "Template type name", content: "shdgf sdjgfjhs jgsdjfgds jhdsfgjsd sdjfhkjsdfh jsddfhkjh." },
  ]

  return (
    <div data-component="template">
      <div className='main-cnt'>
        <Header />
        <Slider />


        <h2 className="heading">Template Types</h2>
        <div className='cards-cnt'>
          {templateTypes.map((item, index) => (
            <TemplateTypeCard key={index} data={item} />
          ))}
        </div>

        <Footer />
      </div>
    </div>
  )
}

export default Templates
