import { useEffect, useRef, useState } from 'react'
import './home.css'
import { HOMEPAGE } from '../../constants/string'
import { useNavigate } from 'react-router-dom';
import Header from '../../components/header/header';
import Slider from '../../components/slider/slider';
import EasyStepsCard from '../../components/easy-steps-card/easyStepsCard';
import step1image from '../../assets/images/step-1-color-cards.avif'
import step2image from '../../assets/images/step-2-skillspost.avif'
import step3image from '../../assets/images/step-3-files.avif'
import FeatureCard from '../../components/feature-card/featureCard';
import logo from '../../assets/images/logo.png';
import Footer from '../../components/footer/footer';


function Home() {

    const navigate = useNavigate();
    const headingRef = useRef();

    const stepsCard = [
        { image: step1image, content: "Choose a customizable template built to impress employers and pass ATS scans." },
        { image: step2image, content: "Choose a customizable template built kjsdhjkfshf dkfbsdfbfds fjdfdf jf sdmffjhsdb ." },
        { image: step3image, content: "shdgf sdjgfjhs jgsdjfgds jhdsfgjsd sdjfhkjsdfh jsddfhkjh." },
    ]

    const featuresCard = [
        { image: logo, heading: "ABCD", content: "jsdhjh ajdgjsda jgsjda jhgasd sajhdg jsagd jsagdj" },
        { image: logo, heading: "DEFG", content: "dshgfsd jhsgdhf sdhf sdjhfsd hjgdhfsd jhsdgf dsjfg" },
        { image: logo, heading: "HIGK", content: "jdhjkh jhgf gjsdgfj jhdsgjgf jdsgf jdgfjhd jsdg sdjfghjf jsdfg" },
        { image: logo, heading: "ABCLMNOD", content: "jhdfj jhsdgf jhsdgfs jgsjdfg jhdsfsd jgjhgf jghjdsgf jhghjdgf jgdhf" },
    ]

    return (
        <div data-component="home">
            <div className='main-cnt'>
                <Header />
                <Slider />

                <h2 className="heading">Build Your Winning Resume in <span style={{ color: '#ff3d3c' }}> 3 Easy Steps</span></h2>
                <div className='steps-card-cnt'>
                    {stepsCard.map((item, index) => (
                        <EasyStepsCard key={index} data={item} />
                    ))}
                </div>

                <h2 className="heading">Features</h2>
                <div className='steps-card-cnt'>
                    {featuresCard.map((item, index) => (
                        <FeatureCard key={index} data={item} />
                    ))}
                </div>

                <Footer />
            </div>
        </div>
    )
}

export default Home
