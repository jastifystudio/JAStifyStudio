import { useState } from 'react'
import './contact.css'
import Header from '../../components/header/header'

function Contact() {

  return (
    <div data-component="contact">
      <div className='main-cnt'>
        <Header />
        <h1 style={{color:'red'}}>CONTACT PAGE</h1>
      </div>
    </div>
  )
}

export default Contact
