import './resumeStudio.css';
import { templates } from '../../constants/template';
import Header from '../../components/header/header';
import { useState } from 'react';
import html2pdf from 'html2pdf.js';

export default function ResumeStudio() {
    const [activeTemplateId, setActiveTemplateId] = useState('template1');
    const [fullName, setFullName] = useState('Emma Chen');
    const [contactInfo, setContactInfo] = useState('Chicago, IL 60603 • (555)555-5555 • emma@example.com');
    const [summary, setSummary] = useState('Dynamic professional dedicated to driving organizational growth and technical optimization.');

    const [education, setEducation] = useState([
        { id: 'edu_1', title: 'Master of Business Administration', school: 'University of California, Berkeley', date: '06/2023' },
    ]);

    const [skills, setSkills] = useState([
        { id: 'skill_1', name: 'Strategic Planning', score: 4 },
    ]);

    const [experience, setExperience] = useState([
        {
            id: 'exp_1',
            title: 'District Manager, 08/2024 to 08/2025',
            company: 'Retail Nexus Group - Chicago, IL',
            bullets: 'Increased sales by 20% across all districts\nManaged a team of 15 to optimize operations'
        }
    ]);

    const [accomplishments, setAccomplishments] = useState([
        { id: 'acc_1', text: 'Achieved Top Performer 2024 in Retail Haven' }
    ]);

    const downloadPDF = () => {
        // Target the element containing your compiled template markup
        const element = document.getElementById('resume-capture-canvas');
        if (!element) return;

        // Configuration setup for rendering high-fidelity prints
        const options = {
            margin: 0, // Keeps document margins flush to let template CSS control padding
            filename: `${fullName.replace(/\s+/g, '_')}_Resume.pdf`,
            image: { type: 'jpeg', quality: 0.98 },
            html2canvas: { 
                scale: 2, // Doubles resolution density to keep text extremely crisp
                useCORS: true // Prevents asset/image canvas loading restrictions
            },
            jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };

        // Execute generation loop
        html2pdf().set(options).from(element).save();
    };

    const addEducation = () => {
        setEducation([...education, { id: 'edu_' + Date.now(), title: '', school: '', date: '' }]);
    }

    const updateEducation = (id, field, val) => {
        setEducation(education.map(i => i.id === id ? { ...i, [field]: val } : i));
    }

    const addSkill = () => {
        setSkills([...skills, { id: 'skill_' + Date.now(), name: '', score: 5 }]);

    }
    const updateSkill = (id, field, val) => {
        setSkills(skills.map(i => i.id === id ? { ...i, [field]: val } : i));
    }
    const addExperience = () => {
        setExperience([...experience, { id: 'exp_' + Date.now(), title: '', company: '', bullets: '' }]);
    }

    const updateExperience = (id, field, val) => {
        setExperience(experience.map(i => i.id === id ? { ...i, [field]: val } : i));
    }

    const addAccomplishment = () => {
        setAccomplishments([...accomplishments, { id: 'acc_' + Date.now(), text: '' }]);
    }

    const updateAccomplishment = (id, val) => {
        setAccomplishments(accomplishments.map(i => i.id === id ? { ...i, text: val } : i));
    }


    const removeItem = (id, type) => {
        if (type === 'edu') setEducation(education.filter(i => i.id !== id));
        if (type === 'skill') setSkills(skills.filter(i => i.id !== id));
        if (type === 'exp') setExperience(experience.filter(i => i.id !== id));
        if (type === 'acc') setAccomplishments(accomplishments.filter(i => i.id !== id));
    };

    const activeTemplate = templates.find(t => t.id === activeTemplateId);

    const getCompiledHTML = () => {
        if (!activeTemplate) return "";
        let rawHTML = activeTemplate.html;
        let rawCSS = activeTemplate.style;

        let eduHTML = "";
        education.forEach(edu => {
            if (activeTemplateId === 'template3' || activeTemplateId === 'template6') {
                eduHTML += `
            <div class="timeline-row-item split-timeline-item">
                <div class="item-date-left item-date-pane">${edu.date}</div>
                <div></div>
                <div class="item-content-details item-details-pane">
                    <div class="item-title"><strong>${edu.title || ''}</strong></div>
                    <div class="item-subtitle">${edu.school || ''}</div>
                </div>
            </div>`;
            } else {
                eduHTML += `
            <div class="item edu-item" style="margin-bottom:12px;">
                <div class="item-title"><strong>${edu.title || ''}</strong>, ${edu.date}</div>
                <div class="item-subtitle">${edu.school || ''}</div>
            </div>`;
            }
        });

        // 3. Parse Skills Matrix Badges & Rating Bars
        let skillsHTML = "";
        skills.forEach(item => {
            const percentage = Math.round((item.score / 6) * 100);
            if (activeTemplateId === 'template5' || activeTemplateId === 'template7') {
                skillsHTML += `<span class="skill-pill-badge outline-skill-box">${item.name}</span>`;
            } else if (activeTemplateId === 'template1' || activeTemplateId === 'template4') {
                skillsHTML += `
            <div class="skill-item skill-progress-item">
                <div class="skill-label skill-name">${item.name}</div>
                <div class="progress-bar bar-track"><div class="progress-fill bar-fill" style="width: ${percentage}%; height:100%;"></div></div>
            </div>`;
            } else {
                // Star/Dot rating fallback
                let dots = "";
                for (let i = 1; i <= 6; i++) {
                    dots += `<span class="bullet ${i <= item.score ? 'filled' : ''}" style="display:inline-block; width:9px; height:9px; border-radius:50%; background-color:${i <= item.score ? '#6a4c93' : '#e2e1e6'}; margin-right:4px;"></span>`;
                }
                skillsHTML += `
          <div class="skill-item skill-item-dotbox skill-dot-row">
              <div class="skill-name skill-label">${item.name}</div>
              <div class="dot-rating dot-track">${dots}</div>
          </div>`;
            }
        });

        // 4. Parse Work History Bullet Points
        let expHTML = "";
        experience.forEach(exp => {
            const lines = exp.bullets.split('\n').filter(l => l.trim() !== '');
            const bulletsHTML = lines.map(l => `<li>${l}</li>`).join('');

            if (activeTemplateId === 'template3' || activeTemplateId === 'template6') {
                expHTML += `
          <div class="timeline-row-item split-timeline-item" style="margin-bottom: 20px;">
              <div class="item-date-left item-date-pane">Timeline</div>
              <div></div>
              <div class="item-content-details item-details-pane">
                  <div class="item-title"><strong>${exp.title}</strong></div>
                  <div class="item-subtitle item-company">${exp.company}</div>
                  <ul class="bullet-list bullet-list-content">${bulletsHTML}</ul>
              </div>
          </div>`;
            } else {
                expHTML += `
          <div class="job-item job-entry-item" style="margin-bottom: 20px;">
              <div class="item-title job-meta-header"><strong>${exp.title}</strong></div>
              <div class="item-subtitle item-company">${exp.company}</div>
              <ul class="bullet-list">${bulletsHTML}</ul>
          </div>`;
            }
        });

        // 5. Parse Accomplishments
        let accHTML = "";
        accomplishments.forEach(acc => {
            if (acc.text.trim() !== "") {
                accHTML += `<li>${acc.text}</li>`;
            }
        });

        const parser = new DOMParser();
        const doc = parser.parseFromString(rawHTML, 'text/html');

        // Target the inner selectors built into your template strings
        const nameEl = doc.querySelector('.res-name');
        const contactEl = doc.querySelector('.res-contact');
        const summaryEl = doc.querySelector('.res-summary');
        const initialsEl = doc.querySelector('.res-initials');
        const eduE1 = doc.querySelector('.res-education');
        const skillsE1 = doc.querySelector('.res-skills');
        const experienceE1 = doc.querySelector('.res-experience');
        const accomplishmentsE1 = doc.querySelector('.res-accomplishments');

        if (nameEl) nameEl.textContent = fullName;
        if (contactEl) contactEl.textContent = contactInfo;
        if (summaryEl) summaryEl.textContent = summary;
        if (eduE1) eduE1.innerHTML = eduHTML;
        if (skillsE1) skillsE1.innerHTML = skillsHTML;
        if (experienceE1) experienceE1.innerHTML = expHTML;
        if (accomplishmentsE1) accomplishmentsE1.innerHTML = accHTML;

        // Handle structural initial signatures if required by template models (e.g., Template 1)[cite: 11]
        if (initialsEl && fullName) {
            initialsEl.textContent = fullName.split(" ").map(n => n[0]).join("/");
        }

        return `
            <style>${rawCSS}</style>
            ${doc.body.innerHTML}
        `;
    }

    return (
        <div className="main-cnt">
            <Header />
            <div className="main-inner-cnt">
                <div className="workspace-sidebar">
                    <h2>Design Selector</h2>
                    <div className="control-group">
                        <label>Active Layout Template</label>
                        <select value={activeTemplateId} onChange={(e) => setActiveTemplateId(e.target.value)}>
                            {templates.map(t => <option key={t.id} value={t.id}>{t.name}</option>)}
                        </select>
                    </div>
                    <div style={{ marginBottom: '20px' }}>
                        <button className="btn-add" onClick={downloadPDF} style={{ width: '100%', padding: '12px', fontSize: '14px', backgroundColor: '#10b981' }}>
                            📥 Download Resume PDF
                        </button>
                    </div>
                    <h2>Personal Identity</h2>
                    <div className="control-group"><label>Full Name</label><input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} /></div>
                    <div className="control-group"><label>Contact Info Bar</label><input type="text" value={contactInfo} onChange={(e) => setContactInfo(e.target.value)} /></div>
                    <div className="control-group"><label>Objective Summary Statement</label><textarea value={summary} onChange={(e) => setSummary(e.target.value)} /></div>

                    <h2>Education List <button className="btn-add" onClick={addEducation}>+ Add Degree</button></h2>
                    {education.map(item => (
                        <div key={item.id} className="interactive-card">
                            <button className="btn-delete" onClick={() => removeItem(item.id, 'edu')}>×</button>
                            <div className="control-group"><label>Degree</label><input type="text" value={item.title} onChange={(e) => updateEducation(item.id, 'title', e.target.value)} /></div>
                            <div className="card-row-grid" style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '10px' }}>
                                <div className="control-group"><label>School</label><input type="text" value={item.school} onChange={(e) => updateEducation(item.id, 'school', e.target.value)} /></div>
                                <div className="control-group"><label>Year</label><input type="text" value={item.date} onChange={(e) => updateEducation(item.id, 'date', e.target.value)} /></div>
                            </div>
                        </div>
                    ))}

                    <h2>Skills Matrix <button className="btn-add" onClick={addSkill}>+ Add Skill</button></h2>
                    {skills.map(item => (
                        <div key={item.id} className="interactive-card">
                            <button className="btn-delete" onClick={() => removeItem(item.id, 'skill')}>×</button>
                            <div className="control-group"><label>Skill Name</label><input type="text" value={item.name} onChange={(e) => updateSkill(item.id, 'name', e.target.value)} /></div>
                            <div className="star-rating-container" style={{ display: 'flex', gap: '5px' }}>
                                {[1, 2, 3, 4, 5, 6].map(num => (
                                    <span key={num} className={`rating-star-btn ${num <= item.score ? 'active' : ''}`} onClick={() => updateSkill(item.id, 'score', num)} style={{ cursor: 'pointer', fontSize: '22px', color: num <= item.score ? '#f59e0b' : '#cbd5e1' }}>★</span>
                                ))}
                            </div>
                        </div>
                    ))}

                    <h2>Work History <button className="btn-add" onClick={addExperience}>+ Add Job</button></h2>
                    {experience.map(item => (
                        <div key={item.id} className="interactive-card">
                            <button className="btn-delete" onClick={() => removeItem(item.id, 'exp')}>×</button>
                            <div className="control-group"><label>Job Title</label><input type="text" value={item.title} onChange={(e) => updateExperience(item.id, 'title', e.target.value)} /></div>
                            <div className="control-group"><label>Company</label><input type="text" value={item.company} onChange={(e) => updateExperience(item.id, 'company', e.target.value)} /></div>
                            <div className="control-group"><label>Achievements</label><textarea value={item.bullets} onChange={(e) => updateExperience(item.id, 'bullets', e.target.value)} /></div>
                        </div>
                    ))}

                    <h2>Accomplishments <button className="btn-add" onClick={addAccomplishment}>+ Add</button></h2>
                    {accomplishments.map(item => (
                        <div key={item.id} className="interactive-card">
                            <button className="btn-delete" onClick={() => removeItem(item.id, 'acc')}>×</button>
                            <div className="control-group"><input type="text" value={item.text} onChange={(e) => updateAccomplishment(item.id, e.target.value)} /></div>
                        </div>
                    ))}


                </div>
                <div className="workspace-sidebar" style={{ width: '68%' }}>
                    <div
                        id="resume-capture-canvas"
                        className="resume-shadow-box"
                        dangerouslySetInnerHTML={{ __html: getCompiledHTML() }}
                    />
                </div>

            </div>
        </div>
    );
}